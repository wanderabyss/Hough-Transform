% Sparse solution heuristics
%
%  sparse_solution.m    - Computing a sparse solution of a set of linear inequalities
%  sparse_infeas_dual.m - Detecting a small subset of infeasible linear inequalities
%  sparse_infeas.m      - Finding a point that satisfies many linear inequalities
help Contents
